# SteadyStep — ESP32 Core Firmware v1

**Purpose:** a provisional firmware prototype for a low-effort home-monitoring platform using three intended measurements: weight, resting heart rate estimated from platform vibration (experimental BCG), and foot-to-foot impedance.

> **Prototype disclaimer:** This software is not a medical device and does not diagnose or rule out heart failure. The thresholds below are engineering placeholders, not clinically validated cut-offs. Do not connect the electrode circuit to a person until the excitation, current limiting, isolation/protection and analogue front end have been independently reviewed. The actual pin map and sensor wiring must be confirmed against the final schematic before powering the hardware.

## 1. System overview — what the ESP32 does

The current sketch follows the team's block diagram provisionally:

1. **Wait for a person.** If both force channels are calibrated, the firmware reads the platform and bar-force channels. If their combined estimate stays at or above 15 kg-equivalent for 700 ms, it starts an automatic 10-second session. A `capture` serial command can start a session manually for bench testing.
2. **Collect sensor samples for 10 seconds.** HX711 samples are collected whenever each module reports data ready. The analogue impedance-front-end output is sampled approximately every 10 ms (nominally 100 samples/second).
3. **Calculate session summaries.** The firmware estimates the platform force, grab-bar vertical support force, combined weight, experimental BCG heart rate, and mean/standard deviation of the impedance ADC counts.
4. **Assess data quality and trends.** Weight and heart rate are checked against this person's baseline and recent threshold history. Impedance is currently stored only as raw ADC counts and does not affect alert decisions.
5. **Save the session locally.** A row is appended to `/sessions.csv` in LittleFS on the ESP32 flash partition. Baselines, calibration and a pending SMS queue are stored separately in Preferences/NVS.
6. **Play a voice prompt.** The DFPlayer Mini plays the numbered MP3 associated with the assessment state, if the module is detected.
7. **Send an SMS when required.** The SIM800L submits an alert to the configured family number. If it cannot send, the pending message is retained and retried later.

**Not included yet:** Wi-Fi upload, dashboard API, dashboard database synchronisation, impedance conversion to ohms, and a validated clinical algorithm.

## 2. Sensor channels assumed by this firmware

| Channel | Provisional hardware mapping | Current output |
|---|---|---|
| Floor platform force | One HX711 connected to the platform load-cell bridge | Calibrated kg-equivalent force |
| Grab-bar vertical support | A second HX711 connected to a separate bar-force sensor/bridge | Calibrated kg-equivalent vertical support force |
| Heartbeat-related vibration | Experimental extraction from the raw platform HX711 samples, as suggested by the block diagram | Heart-rate estimate in BPM only if quality checks pass |
| Foot-to-foot impedance | Conditioned analogue output to ESP32 GPIO34 (ADC1) | ADC mean and standard deviation only; not ohms |

The BOM lists four half-bridge load cells and an MPU6050/ADXL345 accelerometer, but the submitted schematic does not clearly establish the complete mechanical/electrical arrangement for both platform and grab-bar force or clearly wire the accelerometer. This sketch therefore uses the platform load-cell samples for the experimental BCG path and assumes two independent HX711 force channels. **Reconcile this assumption with the actual hardware before building.**

### Provisional GPIO pin map

| Function | ESP32 GPIO | Interface |
|---|---:|---|
| Floor HX711 DOUT / SCK | 32 / 33 | Digital |
| Bar HX711 DOUT / SCK | 18 / 19 | Digital |
| Conditioned impedance analogue output | 34 | ADC1, input only; must remain within ESP32 limits |
| DFPlayer TX -> ESP32 RX / ESP32 TX -> DFPlayer RX | 16 / 17 | UART1, 9600 baud |
| SIM800L TX -> ESP32 RX / ESP32 TX -> SIM800L RX | 26 / 27 | UART2, 9600 baud |

These GPIOs are code defaults, not verified matches to the submitted EasyEDA schematic. Confirm pin wiring, UART levels, board layout and ground scheme before powering the device.

## 3. Calculation logic

### 3.1 Load-cell calibration

The firmware calibrates floor and bar channels separately.

**Step A — tare:** with a channel unloaded, `tare floor` or `tare bar` averages 10 raw HX711 readings and stores the result as the channel offset, `offset`.

**Step B — known load:** apply a known, mechanically safe test load to that channel, then run `cal floor <known_kg>` or `cal bar <known_kg>`. The firmware averages 10 raw readings and calculates the signed scale factor:

```text
countsPerKg = (rawWithKnownLoad - offset) / known_kg
```

**Step C — convert a raw reading to kg-equivalent:**

```text
force_kg_equivalent = (rawReading - offset) / countsPerKg
```

The sign is preserved because load-cell orientation can invert the output. If the scale factor is near zero or calibration has not been completed, the reading is invalid.

Calibration must use known loads in a safe test fixture. For the bar, the applied calibration load must correspond to the correct vertical support-force component. Do not use a person as a calibration mass.

### 3.2 Robust platform and bar summaries

The firmware converts valid raw samples to kg-equivalent units, discards samples from the first **2 seconds** of the session to reduce the step-on/settling transient, and takes the **median** of the remaining samples for each channel.

At least 20 usable samples are required for each summary. A channel is also range-checked. If both summaries pass quality checks, the code computes:

```text
estimated_true_weight_kg = platform_force_kg + grabbar_vertical_support_kg_equivalent
```

This addition is correct only if the bar channel is calibrated for the signed **vertical support component** in compatible kg-equivalent units. Do not add an unsigned total bar force or a horizontal force. The combined estimate must fall between 20 and 250 kg for the session weight to be marked valid. The code also rejects out-of-range platform/bar values.

### 3.3 Experimental BCG heart-rate estimate

The current experiment attempts to extract heartbeat timing from the **raw floor HX711 samples**; it does not use the separately listed MPU6050.

1. Require at least 100 platform samples and a measured sample rate of at least 35 Hz. The source code recommends setting the HX711 RATE pin/configuration for 80 samples/second for this experiment. A high configured rate does not guarantee a reliable BCG signal.
2. Estimate and subtract a slowly changing DC component using an exponential update (`dc += 0.045 * (sample - dc)`). The residual `sample - dc` is treated as the vibration-like signal.
3. Calculate residual RMS over samples at or after 1.5 seconds. Reject near-flat/low-energy signals.
4. Set a peak threshold to `max(0.70 * RMS, 1 raw count)` and look for local maxima above it.
5. Enforce a minimum 300 ms interval between accepted peaks to reduce duplicate detections.
6. Calculate successive peak intervals and keep intervals from **0.30 to 1.50 seconds**.
7. Require at least 3 usable intervals, then calculate the mean interval:

```text
mean_interval_seconds = average(accepted_intervals)
estimated_heart_rate_bpm = 60 / mean_interval_seconds
```

8. Calculate interval coefficient of variation:

```text
CV = standard_deviation(intervals) / mean_interval_seconds
```

The estimate is marked valid only if BPM is between **40 and 180** and `CV <= 0.35`, as well as passing earlier sample/peak checks. This is a simple experimental detector, not a validated heartbeat algorithm. Motion, stance, mechanical resonance, the HX711 sampling rate and the sensor mounting can cause errors. The firmware reports heart rate as unavailable when these checks fail.

### 3.4 Foot-to-foot impedance input (not yet impedance)

GPIO34 is sampled with a nominal 10 ms interval. The firmware calculates:

```text
ADC_mean = sum(ADC_samples) / number_of_samples
ADC_SD   = sample standard deviation of ADC_samples
```

The ADC is configured for 12-bit reads. The log's `impedance_adc_mean` and `impedance_adc_std` are **raw digital counts**, not resistance or impedance in ohms. The `impedance_ohm` column is deliberately left blank. The analogue excitation, current limit, signal conditioning/demodulation and calibration have not been verified; the code therefore sets `IMPEDANCE_FRONT_END_VERIFIED = false` and does not use this channel for alert scoring.

Do not connect electrodes to a person until the analogue circuit has been independently reviewed for safe excitation current, protection and voltage range. GPIO34 must not be driven above the permitted ESP32 ADC voltage.

### 3.5 Personal baseline

Weight and heart rate have separate personal baselines. Each baseline is the **median of up to seven valid sessions** for that channel.

The firmware accepts no more than one baseline contribution per 20 hours. It prefers the SIM800L network clock to check this interval; if there is no trusted clock, it uses an uptime interval during the current power session. Without a dedicated RTC or trustworthy network time, the interval cannot be guaranteed across all power-loss/reboot situations.

A channel's baseline is built only from valid measurements. Until both weight and heart-rate baselines contain seven samples, the system normally reports `CALIBRATING` rather than claiming an all-clear state.

### 3.6 Trend threshold and persistence rules

These constants are **demonstration/engineering placeholders**, not clinically validated thresholds:

```text
Weight threshold:       current weight >= baseline median * 1.02
Heart-rate threshold:   current heart rate >= baseline median * 1.15
Persistence:            threshold exceeded in at least 2 of the last 3 valid post-baseline sessions
```

For example, if the weight baseline median is 70.0 kg, the configured weight threshold is:

```text
70.0 * 1.02 = 71.4 kg
```

If the resting-heart-rate baseline median is 70 BPM, its configured threshold is:

```text
70 * 1.15 = 80.5 BPM
```

Those examples explain the arithmetic only; the thresholds must not be presented as medical cut-offs.

The firmware stores the most recent three threshold-exceedance flags for each signal. A signal counts as persistent only after three post-baseline evaluations have accumulated and at least two flags are positive. The impedance channel does not currently contribute to the score.

### 3.7 Assessment states

| State | Rule in current firmware | Audio track |
|---|---|---:|
| `CALIBRATING` | Fewer than seven baseline samples for weight or heart rate, unless a persistent warning already takes precedence | `mp3/0005.mp3` |
| `INSUFFICIENT_DATA` | No usable assessment, or required weight/heart-rate data is invalid, or impedance front end remains unverified when no persistent weight/heart warning overrides this branch | `mp3/0004.mp3` |
| `WATCH` | Weight **or** heart rate meets its persistence rule | `mp3/0002.mp3` |
| `ELEVATED_PATTERN` | Both weight and heart rate meet their persistence rules | `mp3/0003.mp3` |
| `NO_RULE_TRIGGER` | Baselines ready, valid weight and heart rate, no persistent threshold rule triggered, and impedance path explicitly marked verified | `mp3/0001.mp3` |

Because `IMPEDANCE_FRONT_END_VERIFIED` is currently `false`, the current build cannot produce `NO_RULE_TRIGGER` for an otherwise non-alerting session. This is deliberate: it avoids presenting an all-clear status while the selected three-measurement pipeline is incomplete. Weight/heart-rate persistence can still raise `WATCH` or `ELEVATED_PATTERN`. Do not simply change this constant to `true` without validating the analogue circuit, calibration and signal quality.

A `NO_RULE_TRIGGER` state, when enabled after verification, means only that the configured rules did not trigger. It does not rule out heart failure or another medical problem.

## 4. Audio behaviour

The DFPlayer Mini is controlled over UART1 at 9600 baud. The firmware requests volume level 18 on a 0–30 scale; adjust only after testing the real speaker/module. Copy the included numbered MP3 files to a microSD card in a directory named `mp3` at the card root:

| File | Intended meaning |
|---|---|
| `/mp3/0001.mp3` | Measurement complete; no configured warning change detected (only used if `NO_RULE_TRIGGER` becomes available) |
| `/mp3/0002.mp3` | A persistent change was found; repeat/check and inform a caregiver |
| `/mp3/0003.mp3` | Multiple persistent changes; promptly contact family/health professional |
| `/mp3/0004.mp3` | Readings unavailable/poor quality; repeat or ask caregiver for help |
| `/mp3/0005.mp3` | Personal baseline is still being collected |

The included Tamil audio files are machine-generated starter prompts. Replace them with reviewed and understandable recordings before any user-facing demonstration. Local playback does not require internet access.

## 5. SMS behaviour

The SIM800L is controlled over UART2 at 9600 baud. On startup the firmware tries modem AT commands, sets SMS text mode where supported, and attempts to read network time. An SMS alert is queued in Preferences/NVS before transmission, so the queued message can survive a reset.

- Set the destination using `phone +91XXXXXXXXXX` (use the actual authorised recipient number on the device, not in a public source repository).
- `test_sms` queues an explicit connectivity-test message; it is not sent automatically at boot.
- For a warning, the firmware sends one SMS when a new warning state begins, and sends an escalation if a `WATCH` state becomes `ELEVATED_PATTERN`. It suppresses repeated SMS messages while the same alert state remains active. A later valid `NO_RULE_TRIGGER` session resets the notification state for a future episode.
- The queue is serviced outside the 10-second sampling session. After a failed attempt, the message is retained and another attempt is scheduled after about five minutes. This is a retry policy, not a guarantee of carrier delivery.
- SMS requires a valid SIM, compatible live network coverage and a properly powered modem. The SIM800L must **not** be powered from the ESP32 3.3 V pin; engineer a suitable 3.4–4.4 V supply capable of current bursts up to roughly 2 A and confirm the exact breakout board's logic-level requirements.

## 6. Local data storage

### Preferences/NVS

Stores small configuration/state values: floor and bar calibration offsets/scales, the personal baseline samples and trend flags, the configured family phone number, notification state, and any queued SMS text/state.

### LittleFS CSV log

Appends one summary row per finished session to `/sessions.csv`. The columns are:

- `sequence`, `timestamp_utc`, `uptime_ms`, `device_id`
- `platform_force_kg`, `grabbar_force_kg_eq`, `estimated_true_weight_kg`, `weight_valid`
- `heart_rate_bpm`, `heart_rate_valid`, `heart_rate_interval_cv`
- `impedance_adc_mean`, `impedance_adc_std`, `impedance_ohm`, `impedance_quality`
- `alert_state`, `reason`, per-channel sample counts, and threshold flags

Detailed raw samples are buffered in RAM during a session and are not all written to flash. The log rotates when it grows beyond about 420 KiB and has more than 900 data rows; the implementation retains the latest 900 rows. Check `status` or `storage` to see LittleFS usage. The firmware deliberately does not format the filesystem automatically. `format_fs` followed by `format_fs_confirm` erases all local session history.

The timestamp is UTC when a plausible modem/network clock is available. Otherwise it is `UNSET` and the uptime is recorded; add an RTC or reliable time-sync plan if accurate dates across offline power cycles are required.

## 7. Automatic and manual session control

- Automatic detection is disabled until both floor and bar channels have valid calibration.
- When the combined calibrated force stays at or above 15 kg-equivalent for 700 ms, the firmware starts a 10-second session.
- A cooldown of approximately 20 hours prevents repeated captures while the device remains powered. With network time, it also checks the time since the last session. Without trusted time, reboot-surviving daily suppression is not guaranteed because no dedicated RTC is included.
- `capture` starts a 10-second session manually for testing.
- During capture, modem servicing is deferred so slow SMS transactions do not interrupt sample acquisition. The local speaker is triggered after the session is processed.

## 8. Build and setup

### Arduino IDE

1. Install Arduino IDE and the ESP32 board support package by Espressif Systems.
2. Select the matching ESP32 Dev Module / ESP32-WROOM board.
3. Install libraries: **HX711 by bogde** and **DFRobotDFPlayerMini by DFRobot**.
4. Open `SteadyStep_ESP32_Core.ino`.
5. Select a partition scheme with LittleFS/SPIFFS filesystem space.
6. Check the pin map and hardware assumptions before compiling/uploading.
7. Open Serial Monitor at **115200 baud**, line ending **Newline**.

### PlatformIO

Open the project folder containing `platformio.ini` as a PlatformIO project, then run `pio run`. The declared dependencies are in `platformio.ini`.

### First-time calibration

1. With the platform channel unloaded and mechanically stable, run `tare floor`.
2. Apply a known test mass to the platform channel only, then run `cal floor <known_kg>`.
3. Unload the bar channel and run `tare bar`.
4. Apply a known vertical force using a safe fixture, then run `cal bar <known_kg>`.
5. Run `status` and verify both calibrations are set.
6. Run `test_audio normal`, `test_audio watch`, `test_audio danger`, `test_audio retry`, or `test_audio calibrating` to test prompts.
7. Save the authorised recipient using `phone +91XXXXXXXXXX`; run `test_sms` only when you intend to send a real test message.
8. Run `capture` to test a manual 10-second session; inspect `log_tail` and `storage`.

Do not calibrate on a person. First test the circuit, mechanics, and individual channels with known loads on a bench.

## 9. Serial Monitor commands

| Command | Purpose |
|---|---|
| `help` | List commands |
| `status` | Show sensors, calibrations, baseline, storage, audio and modem status |
| `tare floor` / `tare bar` | Store unloaded raw offset and invalidate the previous scale factor |
| `cal floor <kg>` / `cal bar <kg>` | Calibrate with known test force/load |
| `capture` | Manually run one 10-second session |
| `baseline_reset` | Delete baseline samples/trend history and restart calibration |
| `phone +91XXXXXXXXXX` | Store family phone number in NVS |
| `test_audio normal|watch|danger|retry|calibrating` | Play a selected prompt |
| `test_sms` | Queue an explicit test SMS |
| `log_tail` | Print recent CSV history rows |
| `storage` | Show local filesystem usage |
| `format_fs`, then `format_fs_confirm` | Erase/reinitialize local LittleFS history (destructive) |

## 10. Current limitations and validation status

- The selected GPIO map is provisional; it is not confirmed by the submitted EasyEDA schematic.
- The two HX711 channels require an actual mechanical/schematic design for both floor and grab-bar support forces. The current BOM does not clearly account for the grab-bar sensor arrangement.
- The load-cell BCG algorithm is experimental. It requires verified HX711 sampling configuration, quiet mechanical conditions and real signal-quality testing.
- Foot-to-foot impedance is **not yet calculated in ohms** and does not contribute to alert status. Do not enable the verified flag without engineering review and calibration.
- The 2% weight and 15% heart-rate thresholds are illustrative. They are not clinical cut-offs.
- No Wi-Fi upload/dashboard integration is included in this version.
- The code passed local syntax checks using mock interfaces, but a full Arduino-ESP32/PlatformIO build and physical-hardware tests have not yet been completed. Follow `docs/TEST_PLAN.md` after the real wiring is finalised.
- Use public or computer-generated data for hackathon testing. Collecting data from people requires ethics approval and informed consent as specified by the problem statement.

## Files in this package

- `SteadyStep_ESP32_Core.ino` — Arduino firmware.
- `src/main.cpp`, `platformio.ini` — PlatformIO project entry and dependencies.
- `docs/WIRING_ASSUMPTIONS.md` — wiring items that the team must confirm.
- `docs/TEST_PLAN.md` — bench test plan.
- `docs/SOURCES_AND_LIBRARIES.md` — library/source notes.
- `sd_card/mp3/0001.mp3` through `0005.mp3` — starter Tamil voice prompts for the DFPlayer card.
- `BUILD_STATUS.md` — checks actually performed and limitations.
